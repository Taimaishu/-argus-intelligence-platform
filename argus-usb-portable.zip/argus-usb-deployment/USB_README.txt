
Argus Intelligence Platform - USB Portable Edition
===================================================

QUICK START:

  Windows:
    1. Double-click START_ARGUS_USB.bat
    2. Follow the prompts
    3. Browser will open automatically

  Linux:
    1. Open terminal in this directory
    2. Run: ./START_ARGUS_USB.sh
    3. Follow the prompts
    4. Browser will open automatically

FIRST TIME SETUP:

  1. The setup wizard will guide you through API key configuration
  2. You'll need at least one API key from:
     - OpenAI (recommended): https://platform.openai.com/api-keys
     - Anthropic: https://console.anthropic.com/account/keys
     - Or use Ollama (free, local): https://ollama.ai

STORAGE OPTIONS:

  When prompted, choose where to store data:

  1. USB Drive - Simple, but limited by USB size
  2. External HDD - Recommended for large datasets
  3. System Temp - Temporary, cleared on restart
  4. Custom Path - Specify your own location

REQUIREMENTS:

  - Python 3.10 or higher
  - 2GB+ RAM
  - 500MB+ free space (more for documents)

STOPPING ARGUS:

  - Windows: Press any key in the launcher window
  - Linux: Press Enter in the terminal

DOCUMENTATION:

  See CREATE_USB_DEPLOYMENT.md for detailed information

SUPPORT:

  - Issues: https://github.com/Taimaishu/argus-intelligence-platform/issues
  - Docs: See CREATE_USB_DEPLOYMENT.md

VERSION:

  v1.1 - January 3, 2026
  - Added safe improvements to image/entity search services
  - Enhanced error handling and logging
  - Improved input validation and database transaction safety
  - Setup wizard for first-run experience
  - All core functionality preserved and tested
